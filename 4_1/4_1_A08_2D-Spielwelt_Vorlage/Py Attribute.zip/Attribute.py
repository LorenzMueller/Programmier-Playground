class Taschenrechner():
    def __init__(self):
        self.zahl1 = 1
        self.zahl2 = 2
        self.inhalt = ""

    def methode0(self):
        return self.zahl1 + self.zahl2
    def methode1(self):
        self
        #delete self and code yourself 
    def methode2(self):
        self     
    def methode3(self):
        self
    def methode4(self):
        self
    def methode5(self):
        self
    def methode6(self):
        self
    def methode7(self):
        self
    def methode8(self):
        self
    def methode9(self):
        self

taschenrechner = Taschenrechner()


#Testen der erstellten Methoden
print(taschenrechner.methode0())
taschenrechner.methode1()
#print(taschenrechner.zahl1)
taschenrechner.methode2()
#print(taschenrechner)
taschenrechner.methode3()
#print(taschenrechner.zahl1)
taschenrechner.methode4()
#print(taschenrechner.zahl1)
taschenrechner.methode5()
#print(taschenrechner.inhalt)
taschenrechner.methode6()
#print(taschenrechner)
taschenrechner.methode7()
#print(taschenrechner.inhalt)


taschenrechner2 = Taschenrechner()
taschenrechner2.methode8()
#print(str(taschenrechner2.zahl1) + " " + str(taschenrechner2.zahl2))
taschenrechner2.methode9()
#print(taschenrechner2)
